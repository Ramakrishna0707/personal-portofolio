# Personal-Portfolio
A personal portfolio built with ReactJs and NodeJs 

Necessary Commands:
<br />
npm install //for node packages
<br />
npm i swiper // for slider
<br />
npm i @emailjs/browser //for emailjs library and to get emails
<br />
![Screenshot (90)](https://user-images.githubusercontent.com/63344738/178135556-ce3a6e0d-61ec-46cc-b7f7-593188256ebc.png)
<br />
![Screenshot (94)](https://user-images.githubusercontent.com/63344738/178135559-35396197-96a8-42da-a9f5-7c52da394d58.png)
<br />
![Screenshot (91)](https://user-images.githubusercontent.com/63344738/178135561-f307ed10-be7f-46ef-b68e-cf5880c343fa.png)
<br />
![Screenshot (92)](https://user-images.githubusercontent.com/63344738/178135563-14bd59a4-201b-4eff-a8c3-a50c19bf9889.png)
<br />
![Screenshot (93)](https://user-images.githubusercontent.com/63344738/178135567-44858b86-3a93-40f4-b1d5-b6c5a4482060.png)
